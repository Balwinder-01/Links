try {
} catch (error) {
  res.status(500).json("somthing went wrong....");
}
